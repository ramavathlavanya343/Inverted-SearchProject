#include<stdio.h>
#include"inverted_search.h"


/*extern int db;
  extern int db1;*/

/* function for save the datavase */
int save_database(hash_t *HT, char *file_name)
{

    /* if( db == 0 && db1 == 0)
       {
       printf("\nERROR: Database is not created\n");
       return FAILURE;
       }*/

    /*check if the file name has a .txt extension*/
    if(strstr(file_name,".txt") == NULL)
    {
	return FAILURE;
    }

    FILE *fptr = fopen(file_name,"w"); /*Open the file in write mode*/
    if(fptr == NULL)
    {
	return FAILURE;
    }

    for(int i=0;i<28;i++)
    {
	if(HT[i].link != NULL) /*If the hash table entry is not empty*/
	{
	    Main_Node *mtemp = HT[i].link; /*Pointer to traverse main nodes*/


	    /*Traverse through the main nodes*/
	    while(mtemp)
	    {
		/*Write main node data to the file*/
		fprintf(fptr,"#%d;%s;%d;",i,mtemp->word,mtemp->file_count);

		Sub_Node *stemp = mtemp->slink;

		/* Traverse in the sub nodes */
		while(stemp)
		{
		    fprintf(fptr,"%s;%d;",stemp->f_name, stemp->word_count);
		    stemp = stemp->link;
		}
		fprintf(fptr,"#\n");
		mtemp = mtemp->mlink; /*Move to the next main node*/
	    }
	}
    }
    fclose(fptr);
    return SUCCESS;
}

/*else
{
    printf("\nERROR:Please pass a txt file\n");
    return FAILURE;

}*/





