#include <stdio.h>
#include <stdlib.h>
#include "inverted_search.h"

/*
Name:Lavanya
Date:11 07 2024
Description: Inverted Search
 */

int main(int argc, char *argv[])
{ 
    File_name *list = NULL; /* Pointer to hold the list of file names*/
    hash_t HT[SIZE];  /* Hash table of size 28 to hold the database*/
    create_HT(HT, SIZE); /* Function to initialize the hash table*/


    /* Check if there are command line arguments provided*/
    if(argc > 1)
    {

	/*validate and read the files from command line arguments*/
	if(read_and_validation(argc,argv,&list) == SUCCESS)
	{
	    printf("\nINFO: Read and Validation Successfully :\n\n");
	    print(list);
	}
	else
	{
	    printf("\nINFO:No Such Files\n");
	    printf("INFO:Unable to create the DATA_BASE\n");

	    return 0;
	}

    }

    else
    {
	printf("\nERROR :Please pass files in Command-Line Arguments\n");
    }



    char ch='y';
    int flag=0;

    while((ch == 'y') || (ch == 'Y'))
    {
	int opt;
	char s_word[20];
	char file_name[20];
	char name[20];

	printf("\nSelect your choice among following options:\n");
	printf("--------------------------------------------------------\n");

	printf("1.Create DATABASE\n2.Display Databse\n3.Update DATABASE\n4.Search\n5.Save DataBase\n6.Exit\n");

	printf("---------------------------------------------------------\nEnter your choice :");
	scanf("%d",&opt);

	switch(opt)
	{
	    case 1 :

		if(create_HT(HT,SIZE) != SUCCESS)
		{
		    printf("ERROR: Hash Table creation failed\n");
		}

		/*Create the database from the file list*/
		int res=create_database(list,HT);
		if(res != SUCCESS)
		{

		    printf("\nINFO :Creating Database Failed\n");
		}

		else if(res == CREATED)
		{
		    printf("\nINFO : Database Created Successfully\n");
		}

		else if(res == LIST_EMPTY)
		{
		    printf("\nINFO : List is empty\n");
		}
		else
		{

		    printf("\nINFO : Successfully Created DATABASE for file");
		}


		flag=1;

		break;

	    case 2 : 

		/*Display the contents of the database*/
		if (display_database(HT) != SUCCESS)

		    printf("ERROR;Displaying hash table failed\n");
		break;

	    case 3 :

		/*Update the database with data from a file*/

		printf("\nEnter the filename to update: ");
		scanf("%s", file_name);
		int result = update_database(HT,file_name);
		if ( result != SUCCESS)
		    printf("\nINFO: Data not updated\n");
		else
		    printf("\nINFO: Data updated successfully\n");
		break;

	    case 4 : 

		/*Search for a word in the database*/
		printf("\nEnter the word you want to search :");
		scanf("%s",s_word);
		if(search_word(HT,s_word) == SUCCESS)
		{
		    printf("\nINFO : Word  Found\n");
		}

		else
		{
		    printf("\nINFO :Word Not Found\n");

		}

		break;

	    case 5 :

		/*Save the database to a file*/
		printf("\nEnter the filename to save the database: ");
		scanf("%s",file_name);

		if( save_database(HT,file_name) == SUCCESS)
		{
		    printf("\nINFO: Data saved successfully \n");
		}
		else
		{
		    printf("\nINFO: Failed to save \n");
		}

		break;


	    case 6:
		exit(0);
		break;

	    default:
		printf("Invalid option\n");
		break;
	}
	getchar();
	printf("Do you want to continue?\n");
	printf("Enter y/Y to continue and n/N to discontinue\n");
	scanf("%c", &ch);

    }
    return 0;

}


/*Function to print the list of file names*/
void print(File_name *list)
{
    if(list == NULL)
    {
	printf("List is empty\n");
    }
    else
    {
	File_name *temp = list;
	while(temp)
	{
	    printf("%s-> ",temp->file_name);
	    temp = temp->link;

	}

	printf("NULL\n");

    }
}






