#ifndef INVERTED_SEARCH_H
#define INVERTED_SEARCH_H

#include<stdlib.h>
#include<ctype.h>
#include<string.h>

#define FAILURE 0
#define SUCCESS 1
#define CREATED 1
#define LIST_EMPTY -2
#define SIZE 28
#define w_size 100 




typedef struct file
{
    char file_name[50];
    struct file *link;

}File_name;

typedef struct Hash_Table
{
    int index;
    struct main_node *link;
}hash_t;

typedef struct sub_node
{
    int word_count;
    char f_name[100];
    struct sub_node *link;
}Sub_Node;

typedef struct main_node
{
    int file_count;
    char word[100];
    struct sub_node *slink;
    struct main_node *mlink;
}Main_Node;

/* function prototype for read and validation*/
int read_and_validation(int argc,char *argv[],File_name **list);

int create_HT(hash_t *HT, int size);

int search_duplicate(char *name,File_name **list);

int insert_name(char *name,File_name **list);

void print(File_name *list);

/* function prototypes for create database */

int create_database(File_name *list, hash_t *HT);

Main_Node *create_m_s_node(char *word,char *file_name);

int alpha_int_spec(char *word);

int display_database(hash_t *head);

/* function prototype for search word */

int search_word(hash_t *head, char *s_word);

/* function prototype for save database */
int save_database(hash_t *HT, char *file_name);

int update_database(hash_t *HT, char *filename);

int validateUpdate(FILE **fptr, char *fname);

int create_MN(Main_Node **main, char *word);

int create_SN(Sub_Node **sub, char *fname);



#endif







