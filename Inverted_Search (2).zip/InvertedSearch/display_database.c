#include <stdio.h>
#include "inverted_search.h"

/* Function for Displaying the database which is stored */
int display_database(hash_t *head)
{
    printf("----------------------------------------------------------\n");
    printf("Index\tFile_Count\tWord\tFile_Name\tWord_Count\n");
    printf("----------------------------------------------------------\n");

    /* Run a loop for 28 times */
    for (int i = 0; i < SIZE; i++)
    {
        if (head[i].link != NULL)
        {
            Main_Node *mtemp = head[i].link;

            /* Traverse in the main node */
            while (mtemp != NULL)
            {
                printf("[%d]\t%d\t\t%s\t", i, mtemp->file_count, mtemp->word);

                Sub_Node *stemp = mtemp->slink;

                /* Traverse in the sub nodes */
                while (stemp != NULL)
                {
                    printf("%s\t\t%d\t", stemp->f_name, stemp->word_count);
                    stemp = stemp->link;
                }

                printf("\n");
                mtemp = mtemp->mlink;
            }
        }
    }

   // printf("\n\t\tDisplayed Successfully\n");
    printf("---------------------------------------------------------\n");
    printf("\n\t\tDisplayed Successfully\n");

    printf("\n---------------------------------------------------------\n");
    return SUCCESS;
}

