#include<stdio.h>
#include "inverted_search.h"

/* Function for Searching the word provided by the User */
int search_word(hash_t *head, char *s_word)
{

    /*get the index for the word based on its first character*/
    int index = alpha_int_spec(s_word);

    if(head[index].link == NULL)/*Check if the index in the hash table is empty*/
    {
	return FAILURE;
    }
    else
    {

	Main_Node *temp = head[index].link; /*Pointer to traverse main nodes*/

	/* Traverse in the main node */
	while(temp)
	{
	    if( strcmp(temp->word, s_word) == 0)
	    {

		printf("\nThe Word %s is  present in %d files: ",s_word, temp->file_count);

		Sub_Node *stemp = temp->slink; /*Pointer to traverse sub nodes*/

		/*Traverse through the sub nodes*/
		while(stemp)
		{
		    printf("\t%d times in file %s\n",stemp->word_count,stemp->f_name);
		    stemp = stemp->link; /*Move to the next sub node*/
		}


		printf("\n");
		return SUCCESS;

	    }
	    temp = temp->mlink; /*Move to the next main node*/
	}
    }

    return FAILURE;
}


