#include<stdio.h>
#include "inverted_search.h"

extern int db; /* Global variable to track database creation status*/

/* Function to update the database based on the contents of a file*/
int update_database(hash_t *HT, char *filename)
{
    /* Check if database is already created*/
    if( db == 1)
    {
        printf("\nERROR: Database is already created and cannot be updated\n");
        return FAILURE;
    }

    FILE *fptr;
    char buffer[100];
    char *backup;
    int index;
    Main_Node *main = NULL;
    Sub_Node *sub = NULL;

    /* Validate the file for update*/
    if(validateUpdate(&fptr, filename) != SUCCESS)
    {
        return FAILURE;
    }

    printf("\nINFO: Passed file is a saved file\n");

    /*Create a new hash table*/
    if( create_HT(HT, 28) != SUCCESS)
    {
        printf("\nERROR: Hash table is not created\n");
        return FAILURE;
    }

    /* Read data from the file and update the hash table*/
    while((fscanf(fptr,"%s",buffer)) > 0)
    {
        /* Parse the buffer to extract index*/
        backup = strtok(buffer,"#;");
        index = atoi(backup);

        /* Create a new main node*/
        backup = strtok(NULL,"#;");
        if(create_MN(&main,backup) != SUCCESS)
        {
            printf("ERROR: Main node is not created\n");
            return FAILURE;
        }

        /* Set the file count for the main node*/
        backup = strtok(NULL,"#;");
        main->file_count = atoi(backup);

        /* Create sub nodes for the main node*/
        for(int i=0; i<main->file_count; i++)
        {
            backup = strtok(NULL,"#;");
            if(create_SN(&sub, backup) != SUCCESS)
            {
                printf("ERROR: Sub node is not created\n");
                return FAILURE;
            }

            /* Parse the buffer to extract word count*/
            backup = strtok(NULL,"#;");
            sub->word_count = atoi(backup);

            /* Link sub node to main node*/
            if (main->slink == NULL)

            {
                main->slink = sub;
            }
            else
            {
                Sub_Node *stemp = main->slink;

                /* Traverse to the end of the sub node list*/
                while(stemp->link != NULL)
                {
                    stemp = stemp->link;
                }

                /* Link new sub node to the end of the list*/
                stemp->link = sub;
            }
        }

        /* Link main node to the hash table at the computed index*/
        if ( HT[index].link == NULL)
        {
            HT[index].link = main;
        }
        else
        {
            Main_Node *mtemp = HT[index].link;

            /* Traverse to the end of the main node list*/
            while(mtemp->mlink != NULL)
            {
                mtemp = mtemp->mlink;
            }

            /* Link new main node to the end of the list*/
            mtemp->mlink = main;
        }
    }

    /* Close the file after processing*/
    fclose(fptr);
    return SUCCESS;
}

/* Function to validate the file for update*/
int validateUpdate(FILE **fptr, char *fname)
{
    char buffer[100];

    /* Check if the file name ends with ".txt"*/
    if(strcmp(strstr(fname,"."),".txt") != 0)
    {
        printf("ERROR: Please pass a txt file\n");
        return FAILURE;
    }

    /* Open the file for reading*/
    (*fptr) = fopen(fname,"r");
    if((*fptr) == NULL)
    {
        printf("ERROR: File is not present\n");
        return FAILURE;
    }

    /* Check if the file is empty*/
    fseek((*fptr),0,SEEK_END);
    if(ftell(*fptr) == 0)
    {
        printf("ERROR: File is empty\n");
        return FAILURE;
    }
    rewind(*fptr);

    /* Check if the file format indicates it is a saved file*/
    fscanf((*fptr),"%s",buffer);
    if(buffer[0] != '#' || buffer[strlen(buffer)-1] != '#')
    {
        printf("ERROR: File is not saved file\n");
        return FAILURE;
    }

    /* Rewind the file pointer to the beginning*/
    rewind(*fptr);

    return SUCCESS;
}

