#include <stdio.h>
#include "inverted_search.h"

#if 1
int db; /*Global variable to indicate if the database has been created*/

/*Function to create the database from the list of files */
int create_database(File_name *list, hash_t *HT)
{
    File_name *temp = list;/*Temporary pointer to iterate through the file list*/
    
    char word[30];/*Buffer to store each word read from the file*/
    int index; /*Index to store the hash table index for each word*/

    if(temp == NULL)
    {
	return LIST_EMPTY;
    }

    /* run a loop upto last node of file linked list */
    while(temp)
    {
	FILE *fptr = fopen(temp->file_name,"r");
	if(fptr == NULL)
	{
	    printf("ERROR:Unable to open file %s\n",temp->file_name);
	    return FAILURE;
	}

	/* Read words from the file until the end of the file*/
	while(fscanf(fptr,"%s",word) != EOF)
	{
	    index = alpha_int_spec(word);

	    if(HT[index].link == NULL)
	    {
		HT[index].link = create_m_s_node(word,temp->file_name);
	    }
	    else
	    {
		Main_Node *mtemp = HT[index].link; /*temporary pointer to traverse main nodes*/
		Main_Node *m_prev = NULL; /*Pointer to keep track of previous main node*/
		int flag1 = 0;

		/*traverse through main nodes to find if the word already exists*/
		while(mtemp)
		{
		    if(strcmp(word,mtemp->word) == 0)
		    {
			Sub_Node *stemp = mtemp->slink;/*Temporary pointer to traverse sub nodes*/
			Sub_Node *s_prev = NULL;/*Pointer to keep track of previous sub node*/
			int flag2=0;


			/*Traverse through sub nodes to find if the file name already exists*/
			while(stemp)
			{
			    if(strcmp(stemp->f_name,temp->file_name) == 0) /*If file name is found*/
			    {
				stemp->word_count++;/*increment the word count*/
				flag2=1;
				break;
			    }

			    s_prev = stemp;
			    stemp = stemp->link;
			}

			if(flag2 == 0)
			{
			    Sub_Node *snew = malloc(sizeof(Sub_Node));

			    if(snew == NULL)
			    {
				printf("ERROR: Memory allocation Faile\n");
				fclose(fptr);
				return FAILURE;
			    }
			    strcpy(snew->f_name,temp->file_name);
			    snew->word_count = 1;
			    snew->link=NULL;

			    if(s_prev == NULL)
			    {
				mtemp->slink = snew;
			    }
			    else
			    {
				s_prev->link = snew;
			    }
			    mtemp->file_count++;
			}
			flag1=1;
			break;
		    }
		    m_prev = mtemp;
		    mtemp = mtemp->mlink;
		}
		if(flag1 == 0)
		{
		    m_prev->mlink=create_m_s_node(word,temp->file_name);
		}
	    }
	}
	temp=temp->link;
	db = 1;
    }
    return SUCCESS;
}


/* function for creat main nd sub node */
Main_Node *create_m_s_node(char *word,char *file_name)
{

    Main_Node *m_new=malloc(sizeof(Main_Node)); /*Allocate memory for new main node*/
    Sub_Node *s_new =malloc(sizeof(Sub_Node)); /*Allocate memory for new sub node*/

    if(m_new == NULL || s_new == NULL)
    {
	printf("ERROR:Memory allocation failed\n");
	return FAILURE;

    }

    strcpy(m_new->word,word);

    m_new->file_count=1;
    m_new->mlink=NULL; /*Initialize main node link to NULL*/
    m_new->slink=s_new; /*Link the sub node to main node*/
    strcpy(s_new->f_name,file_name);

    s_new->word_count=1;
    s_new->link=NULL;
    return m_new;
}


/* function for find word is int or alpha or spec chara */
int alpha_int_spec(char *word)
{
    int index;

    if((word[0] >= 'a' && word[0] <= 'z') || (word[0] >= 'A'&& word[0] <= 'Z'))
    {
	index=tolower(word[0]) - 97;
	return index;
    }

    else if(word[0] >= '0' && word[0] <= '9')
    {
	return 26;
    }
    else
    {
	return 27;
    }
}

#endif






