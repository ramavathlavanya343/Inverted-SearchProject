#include <stdio.h>
#include "inverted_search.h"


/*Function to read and validate the input files */
int read_and_validation(int argc, char *argv[],File_name **list)
{
    
    for(int i=1;i<argc;i++)
    {

	/*Check if the file has a .txt extension*/
	if(strcmp(strstr(argv[i],"."),".txt") == 0 )
	{
	    
	    FILE *fptr=fopen(argv[i],"r");
	    if(fptr == NULL) /*Check if the file exists*/
	    {
		printf("\nINFO:File Not Present\n");;
	    }
	    else
	    {

		/* Check if the file is empty*/
		fseek(fptr,0,SEEK_END);
		if(ftell(fptr) == 0)
		{
		    printf("\nINFO:File %s is Empty\n",argv[i]);

		}
		else
		{

		    /*Check for duplicate file names in the list*/
		    if(search_duplicate(argv[i],list) == SUCCESS)
		    {
			printf("\nINFO: Duplicate is found for %s\n",argv[i]);
			
		    }
		    else  
		    {
			/* insert the file name into the list */
			if(insert_name(argv[i],list) == SUCCESS)
			{
			    printf("\nINFO: File %s is added Successfully\n",argv[i]);
			}

			else
			{
			    printf("\nERROR File %s is not added\n",argv[i]);
			}

		    }

		}

		fclose(fptr);

	    }
	}
		  
    else
    {
	printf("\nERROR : Please pass a .txt file. %s is not a .txt file\n",argv[i]);
    }
	
    }

    return SUCCESS;

    
}

/*Function to search for duplicate file names in the list*/
int search_duplicate(char *name,File_name **list)
{
    /* If list is empthy no duplicates*/
    if( *list == NULL)
    {
	return FAILURE;
    }

    File_name *temp = *list; /*Temporary pointer to traverse the list*/

    /* Traverse through the list to find if the file name already exists*/
    while(temp)
    {
	if(strcmp(temp->file_name,name) == 0 )
	{
	    return SUCCESS;
	}
	temp = temp->link;
    }
    return FAILURE;

}



/* insert the file name into the list */
int insert_name(char *name,File_name **list)
{
    File_name *new = malloc(sizeof(File_name)); /*Allocate memory for the new node*/
    if (new == NULL)
    {
	printf("Memory not allocated\n");
	return FAILURE;
    }

    strcpy(new->file_name,name); /*Copy the file name into the new node*/
    new->link = NULL; /* set the link of the new node to NULL*/

    if(*list == NULL)
    {
	*list = new;
	return SUCCESS;
    }

    File_name *temp = *list; /*Temporary pointer to traverse the list*/

  //  File_name *prev=NULL;

    while(temp->link)
    {
	
	   
	temp = temp->link;
    }
    temp->link = new; /*Insert the new node at the end of the list*/
    return SUCCESS;
}











