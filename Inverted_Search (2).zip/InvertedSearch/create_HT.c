#include <stdio.h>
#include "inverted_search.h"

int create_HT(hash_t *HT, int size)
{
    for ( int i=0; i<size ; i++)
    {
	HT[i].index = i;
	HT[i].link = NULL;
    }
    return SUCCESS;
}
int create_MN(Main_Node **main, char *word)
{
    *main = (Main_Node *) malloc(sizeof(Main_Node)); // Allocate memory for new main node
    if (*main == NULL)
    {
        printf("\nERROR: Memory not allocated\n");
        return FAILURE; // Return FAILURE if memory allocation fails
    }

    // Initialize fields of the main node
    (*main)->file_count = 1;
    strcpy((*main)->word, word);
    (*main)->mlink = NULL;
    (*main)->slink = NULL;

    return SUCCESS;
}
int create_SN(Sub_Node **sub, char *fname)
{
    *sub = (Sub_Node *) malloc(sizeof(Sub_Node)); // Allocate memory for new sub node
    if (*sub == NULL)
    {
        printf("\nERROR: Memory not allocated\n");
        return FAILURE; // Return FAILURE if memory allocation fails
    }

    // Initialize fields of the sub node
    (*sub)->word_count = 1;
    strcpy((*sub)->f_name, fname);
    (*sub)->link = NULL;

    return SUCCESS;
}


